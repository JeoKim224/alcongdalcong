package util;

public class CommonStrings {
	public static final String success = "SUCCESS";
	public static final String denied = "DENIED";
	
	// User Status Value
	public static final String good = "good";
	
	// user code
	public static final String child = "Child";
	public static final String parent = "Parent";
}
