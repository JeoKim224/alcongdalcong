package appUsage.model;

import java.util.Date;

public class AppUsage {
	private String id;
	private String appName;
	private int useTime;
	private Date usedDate;
	
	/** Constructors **/
	public AppUsage(String id, String appName) {
		this.id = id;
		this.appName = appName;
		
		// default values
		this.useTime = 0;
		this.usedDate = new Date();
	}
	public AppUsage(String id, String appName, int useTime) {
		this.id = id;
		this.appName = appName;
		this.useTime = useTime;
		
		// default value
		this.usedDate = new Date();
	}
	public AppUsage(String id, String appName, int useTime, Date usedDate) {
		this.id = id;
		this.appName = appName;
		this.useTime = useTime;
		this.usedDate = usedDate;
	}


	/** Getters and Setters **/
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public int getUseTime() {
		return useTime;
	}
	public void setUseTime(int useTime) {
		this.useTime = useTime;
	}
	public Date getUsedDate() {
		return usedDate;
	}
	public void setUsedDate(Date usedDate) {
		this.usedDate = usedDate;
	}
}
