package appUsage.service;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import appUsage.dao.AppUsageDao;
import appUsage.model.AppUsage;

public class AppUsageServiceImpl implements AppUsageService {
	
	private AppUsageDao appUsageDao;
	
	public void setUserDao(AppUsageDao appUsageDao){
		this.appUsageDao = appUsageDao;
	}

	@Override
	public int updateAppUsage(String appList) {
		int rtn = 0;
		
		// parse json data(param)
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			List<AppUsage> dataList = mapper.readValue(appList, new TypeReference<List<AppUsage>>(){});

			// put them in List<AppUsage>
			// and then pass it to AppUsageDao
			rtn = appUsageDao.updateAppUsage(dataList);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return rtn;
	}
}
