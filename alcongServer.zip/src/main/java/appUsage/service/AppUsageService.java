package appUsage.service;

public interface AppUsageService {
	public int updateAppUsage(String appList);
}
