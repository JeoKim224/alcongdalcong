package appUsage.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import appUsage.model.AppUsage;

public class AppUsageDaoImpl implements AppUsageDao {

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
		this.sqlSession = sqlSession;
	}

	@Override
	public int updateAppUsage(List<AppUsage> usages) {
		int total = 0;
		for(AppUsage appUsage : usages) {
			total += sqlSession.insert("appusagedao.updateAppUsage", appUsage);
		}
		
		return total;
	}


	@Override
	public List<AppUsage> getAppUsageList(String id, Date date) {
		// TODO Auto-generated method stub
		return null;
	}

}
