package appUsage.dao;

import java.util.Date;
import java.util.List;

import appUsage.model.AppUsage;

public interface AppUsageDao {
	public int updateAppUsage(List<AppUsage> usages);
	
	public List<AppUsage> getAppUsageList(String id, Date date);
}
