package restapi;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import appUsage.service.AppUsageService;

@Path("/appUsage")
@Component
public class AppUsageRestApi {

	@Autowired
	private AppUsageService appUsageService;
	
	@POST
	@Path("{id}")
	public Response updateAppUsage(
			@FormParam("data") String jsonData,
			@FormParam("passwd") String pw) {
		
		// TODO : add password check routine here....
		
		appUsageService.updateAppUsage(jsonData);
		
		return Response.status(200).entity("").build();
	}
	
	@GET
	@Path("{id}/{date}")
	public Response getAppUsage(
			@PathParam("id") String id,
			@PathParam("date") String date,
			@FormParam("passwd") String pw) {
		
		// TODO : add password check routine here....
		
		// TODO : get app usage data here....
		
		return Response.status(200).entity("").build();
	}
}
