package restapi;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import user.model.Token;
import user.service.UserService;
import util.CommonStrings;

@Path("/user")
@Component
public class UserRestApi {

	@Autowired
	private UserService userService;
	
	ObjectMapper mapper = new ObjectMapper();

	@POST
	public Response register(
			@FormParam("id")String id,
			@FormParam("passwd")String pw,
			@FormParam("name")String name,
			@FormParam("phone")String phone,
			@FormParam("code")String code,
			@FormParam("position")String position,
			@FormParam("b_day")String birthday) {
		
		String rtn = CommonStrings.denied;
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date b_day = null;
		try {
			b_day = transFormat.parse(birthday);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		if (userService.register(id, pw, name, phone, code, position, b_day)) {
			rtn = CommonStrings.success;
		}
		
		return Response.status(200).entity(rtn).build();
	}
	
	@POST
	@Path("{id}/password")
	public Response changePassword(
			@PathParam("id") String id,
			@FormParam("passwd") String pw,
			@FormParam("newpasswd") String newPw
			) {
		String ret = CommonStrings.denied;
		
		if(userService.changePassword(id, pw, newPw)) {
			ret = CommonStrings.success;
		}
		
		return Response.status(200).entity(ret).build();
	}
	
	@POST
	@Path("{id}/code")
	public Response changeCode(
			@PathParam("id") String id,
			@FormParam("passwd") String pw,
			@FormParam("newcode") String code
			) {
		String ret = CommonStrings.denied;
		
		if(userService.setCode(id, pw, code)) {
			ret = CommonStrings.success;
		}
		
		return Response.status(200).entity(ret).build();
	}
	
	@POST
	@Path("{id}/token")
	public Response makeAccessToken(
			@PathParam("id") String id,
			@FormParam("passwd") String pw) {

		Token token = userService.getAuthToken(id, pw);
		String tokenString = null;
		try {
			tokenString = mapper.writeValueAsString(token);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(token != null) {
			return Response.status(200).entity(tokenString).build();
		} else {
			return Response.status(400).entity("Access Denied.").build();
		}
	}
}
