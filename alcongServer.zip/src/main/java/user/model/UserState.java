package user.model;

import util.CommonStrings;

public class UserState {
	private String id;
	private String state;
	private int kong;
	private int total;
	
	
	public UserState(String id) {
		this.id = id;
		this.state = CommonStrings.good;
		this.kong = 0;
		this.total = 0;
	}
	
	public UserState(String id, String state, int kong, int total) {
		this.id = id;
		this.state = state;
		this.kong = kong;
		this.total = total;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getKong() {
		return kong;
	}
	public void setKong(int kong) {
		this.kong = kong;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	
}
