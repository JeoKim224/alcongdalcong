package user.model;

import java.sql.Timestamp;

public class Token {
	String id;
	String token;
	Timestamp timestamp;
	
	/** constructor **/
	public Token(String id, String token, Timestamp timestamp) {
		this.id = id;
		this.token = token;
		this.timestamp = timestamp;
	}
	
	/** getter and setter **/
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
}
