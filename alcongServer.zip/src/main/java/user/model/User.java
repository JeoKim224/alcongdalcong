package user.model;

import java.util.Date;

public class User {
	private String id;
	private String passwd;
	private String name;
	private String phone;
	private String code;
	private String position;
	private Date b_day;
	private Date regi_date;
	
	/* Constructors */
	public User() {
		super();
	}
	public User(String id, String passwd, String name, String phone,
			String code, String position, Date b_day) {
		super();
		this.id = id;
		this.passwd = passwd;
		this.name = name;
		this.phone = phone;
		this.code = code;
		this.position = position;
		this.b_day = b_day;
	}
	
	/* Getters and Setters */
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Date getB_day() {
		return b_day;
	}
	public void setB_day(Date b_day) {
		this.b_day = b_day;
	}
	public Date getRegi_date() {
		return regi_date;
	}
	public void setRegi_date(Date regi_date) {
		this.regi_date = regi_date;
	}
}
