package user.service;

import java.util.Date;

import javax.ws.rs.core.Response;

import user.model.Token;

public interface UserService {
	
	public Response addTest();

	public boolean register(String id, String pw, String name, String phone, String code, String position, Date b_day);
	
	public boolean setCode(String id, String pw, String code);
	
	public boolean changePassword(String id, String pw, String newPw);
	
	public Token getAuthToken(String id, String pw);
}
