package user.service;

import java.sql.Timestamp;
import java.util.Date;

import javax.ws.rs.core.Response;

import user.dao.UserDao;
import user.model.Token;
import user.model.User;
import user.model.UserState;
import util.CommonStrings;
import util.Encrypt;

public class UserServiceImpl implements UserService{
	
	private UserDao userDao;
	
	public void setUserDao(UserDao userDao){
		this.userDao = userDao;
	}

	@Override
	public Response addTest(){
		User user = new User("khw0867", "1234", "Hyeonwook", "010-2716-0863",
				"aef0123", "parent", new Date());
		int r = userDao.joinUser(user);
		
		return Response.status(200).entity("return value : " + r).build();
	}
	
	@Override
	public boolean register(String id, String pw, String name, String phone, String code, String position, Date b_day){
		User newUser = new User(id, pw, name, phone, code, position, b_day);

		userDao.joinUser(newUser);

		// set User State for CHILD users
		if(code.equals(CommonStrings.child)) {
			UserState newUserState = new UserState(id);
			userDao.createUserState(newUserState);
		}
		
		return true;
	}
	

	@Override
	public boolean setCode(String id, String pw, String code){
		boolean ret = false;
		
		if(userDao.checkUserPassword(id, pw)) {
			userDao.updateUserCode(id, code);
			ret = true;
		}
		
		return ret;
	}
	
	@Override
	public boolean changePassword(String id, String pw, String newPw){
		boolean ret = false;
		
		if(userDao.checkUserPassword(id, pw)) {
			userDao.updateUserPassword(id, newPw);
			ret = true;
		}
		
		return ret;
	}
	
	@Override
	public Token getAuthToken(String id, String pw) {
		if(userDao.checkUserPassword(id, pw)) {
			Date date = new Date();
			Timestamp timestamp = new Timestamp(date.getTime());
			
			String tokenValue = Encrypt.SHA256(id + timestamp + Math.random());
			
			Token token = new Token(id, tokenValue, timestamp);
			
			userDao.createAccessToken(token);
			return token;
		} else {
			// case for wrong id and password
			return null;
		}
	}
}