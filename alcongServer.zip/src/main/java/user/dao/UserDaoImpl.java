package user.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import user.model.Token;
import user.model.User;
import user.model.UserState;

public class UserDaoImpl implements UserDao{

	private SqlSession sqlSession;
	
	public void setSqlSession(SqlSession sqlSession){
		this.sqlSession = sqlSession;
	}
	
	@Override
	public int joinUser(User user){
		return sqlSession.insert("userdao.setUser", user);
	}

	@Override
	public User getUser(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteUser(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateUser(User user) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	@Override
	public int createUserState(UserState state) {
		return sqlSession.insert("userdao.setUserState", state);
	}
	
	@Override
	public boolean checkUserPassword(String id, String pw){
		boolean ret = false;
		String prevPw = (String) sqlSession.selectOne("userdao.getUserPassword", id);
		
		if(prevPw.equals(pw)){
			ret = true;
		}
		
		return ret;
	}
	
	@Override
	public int updateUserPassword(String id, String newPw){
		Map<String, String> param = new HashMap<String, String>();
		param.put("id", id);
		param.put("passwd", newPw);
		
		return sqlSession.update("userdao.updateUserPassword", param);
	}
	
	@Override
	public int updateUserCode(String id, String newCode) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("id", id);
		param.put("code", newCode);
		
		return sqlSession.update("userdao.updateUserCode", param);
	}
	
	@Override
	public int createAccessToken(Token token) {		
		return sqlSession.insert("userdao.createAccessToken", token);
	}
	
	@Override
	public Token getAccessToken(String id) {
		Token token = (Token) sqlSession.selectOne("userdao.getAccessToken", id);
		
		return token;
	}
}
