package user.dao;

import user.model.Token;
import user.model.User;
import user.model.UserState;

public interface UserDao{	
	public int joinUser(User user);
	
	public User getUser(String id);
	
	public int deleteUser(User user);
	
	public int updateUser(User user);
	
	public int createUserState(UserState state);
	
	public boolean checkUserPassword(String id, String pw);
	
	public int updateUserPassword(String id, String newPw);
	
	public int updateUserCode(String id, String newCode);
	
	public int createAccessToken(Token token);
	
	public Token getAccessToken(String id);
}
